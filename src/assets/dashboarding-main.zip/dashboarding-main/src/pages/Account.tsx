
const Account = () => {
    return (
      <div className='column-dbos-center' style={{ minHeight: '100vh', flexDirection: 'column', alignItems: 'center', backgroundColor: '#F9F9F9' }}>
        <h1>Account</h1>
        <p>Contenido de la página...</p>
      </div>
    );
  };
  
  export default Account;
  