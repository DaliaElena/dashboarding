export const API_URL_DATA: string = 'https://run.mocky.io/v3/419c3394-42b7-4b89-aaa4-825f7ee84986';
export const API_URL_DATA_SOURCE: string = 'https://run.mocky.io/v3/68ce785e-d4f3-4e57-8f6e-dfa62b1a87a7';
export const API_URL_CHART: string = 'https://run.mocky.io/v3/745294d3-3291-42c8-9660-33f0386b5f48';
export const API_URL_WORKERS: string = 'https://run.mocky.io/v3/305a54f7-a926-4f51-8961-194c9327e77c';
export const API_URL_WORKERS_CARDS: string = 'https://run.mocky.io/v3/4ed2856e-1c7e-4115-b15b-eb29cea49e7c';
