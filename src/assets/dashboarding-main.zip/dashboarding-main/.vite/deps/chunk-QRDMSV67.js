import {
  init_utils,
  utils_exports
} from "./chunk-MPGLKCME.js";
import {
  __commonJS,
  __toCommonJS
} from "./chunk-V4OQ3NZ2.js";

// node_modules/@mui/icons-material/utils/createSvgIcon.js
var require_createSvgIcon = __commonJS({
  "node_modules/@mui/icons-material/utils/createSvgIcon.js"(exports) {
    "use strict";
    "use client";
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    Object.defineProperty(exports, "default", {
      enumerable: true,
      get: function() {
        return _utils.createSvgIcon;
      }
    });
    var _utils = (init_utils(), __toCommonJS(utils_exports));
  }
});

export {
  require_createSvgIcon
};
//# sourceMappingURL=chunk-QRDMSV67.js.map
