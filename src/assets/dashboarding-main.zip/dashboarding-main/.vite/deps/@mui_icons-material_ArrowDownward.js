"use client";
import {
  require_createSvgIcon
} from "./chunk-QRDMSV67.js";
import {
  require_interopRequireDefault
} from "./chunk-T5KXVJOC.js";
import "./chunk-MPGLKCME.js";
import "./chunk-UMEDJZTI.js";
import "./chunk-XMLPR76G.js";
import "./chunk-AQHXBISI.js";
import "./chunk-O4VLLPLO.js";
import {
  require_jsx_runtime
} from "./chunk-AXANZMPT.js";
import "./chunk-FWNK54VO.js";
import "./chunk-2PIBWAMS.js";
import {
  __commonJS
} from "./chunk-V4OQ3NZ2.js";

// node_modules/@mui/icons-material/ArrowDownward.js
var require_ArrowDownward = __commonJS({
  "node_modules/@mui/icons-material/ArrowDownward.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "m20 12-1.41-1.41L13 16.17V4h-2v12.17l-5.58-5.59L4 12l8 8z"
    }), "ArrowDownward");
  }
});
export default require_ArrowDownward();
//# sourceMappingURL=@mui_icons-material_ArrowDownward.js.map
