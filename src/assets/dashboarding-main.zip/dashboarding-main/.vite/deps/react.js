import {
  require_react
} from "./chunk-2PIBWAMS.js";
import "./chunk-V4OQ3NZ2.js";
export default require_react();
//# sourceMappingURL=react.js.map
