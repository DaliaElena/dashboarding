"use client";
import {
  require_createSvgIcon
} from "./chunk-QRDMSV67.js";
import {
  require_interopRequireDefault
} from "./chunk-T5KXVJOC.js";
import "./chunk-MPGLKCME.js";
import "./chunk-UMEDJZTI.js";
import "./chunk-XMLPR76G.js";
import "./chunk-AQHXBISI.js";
import "./chunk-O4VLLPLO.js";
import {
  require_jsx_runtime
} from "./chunk-AXANZMPT.js";
import "./chunk-FWNK54VO.js";
import "./chunk-2PIBWAMS.js";
import {
  __commonJS
} from "./chunk-V4OQ3NZ2.js";

// node_modules/@mui/icons-material/Edit.js
var require_Edit = __commonJS({
  "node_modules/@mui/icons-material/Edit.js"(exports) {
    var _interopRequireDefault = require_interopRequireDefault();
    Object.defineProperty(exports, "__esModule", {
      value: true
    });
    exports.default = void 0;
    var _createSvgIcon = _interopRequireDefault(require_createSvgIcon());
    var _jsxRuntime = require_jsx_runtime();
    var _default = exports.default = (0, _createSvgIcon.default)((0, _jsxRuntime.jsx)("path", {
      d: "M3 17.25V21h3.75L17.81 9.94l-3.75-3.75zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a.9959.9959 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z"
    }), "Edit");
  }
});
export default require_Edit();
//# sourceMappingURL=@mui_icons-material_Edit.js.map
